package com.dh.test;

import com.dh.dao.ConfiguracionJDBC;
import com.dh.dao.impl.PerroDaoH2;
import com.dh.model.Perro;
import com.dh.service.PerroService;
import org.junit.Assert;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class PerroServiceTest {
    private PerroService perroService = new PerroService(new PerroDaoH2(new ConfiguracionJDBC()));

    @Test
    void guardar() {
        Perro p1 = new Perro("Dolmancé", "French Bulldog");
        Perro perroGuardado = perroService.guardar(p1);
        Assert.assertTrue(perroGuardado.getId() != null);
    }

    @Test
    void buscarTodos() {
        List<Perro> perros = perroService.buscarTodos();
        Assert.assertTrue(perros.size() != 0);
    }
}